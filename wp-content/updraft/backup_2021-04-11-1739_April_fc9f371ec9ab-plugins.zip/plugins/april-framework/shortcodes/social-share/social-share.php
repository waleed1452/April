<?php
/**
 * Created by PhpStorm.
 * User: thanglk
 * Date: 11/08/2017
 * Time: 10:27 AM
 */
if (!defined('ABSPATH')) {
	die('-1');
}
class WPBakeryShortCode_GSF_Social_Share extends G5P_ShortCode_Base {

}