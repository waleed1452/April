<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}

/**
 * Include the main theme class.
 */
include_once get_template_directory() . '/inc/class-g5plus-theme.php';
