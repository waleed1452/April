<?php
/**
 * The template for displaying post-title.php
 *
 * @package WordPress
 * @subpackage april
 * @since april 1.0
 */
?>
<h4 class="gf-post-title heading-color"><a title="<?php the_title() ?>" href="<?php the_permalink() ?>" class="gsf-link"><?php the_title() ?></a></h4>
