<?php
/**
 * The template for displaying chasing-dots.php
 *
 * @package WordPress
 * @subpackage april
 * @since april 1.0
 */
?>
<div class="sk-chasing-dots">
	<div class="sk-child sk-dot1"></div>
	<div class="sk-child sk-dot2"></div>
</div>

